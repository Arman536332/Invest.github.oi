
import React from "react";

const investments = [
  {
    vip: "VIP3",
    name: "BP Energy 3",
    dailyIncome: "৮৫০.০০",
    cost: "৩,৬০০.০০",
  },
  {
    vip: "VIP4",
    name: "BP Energy 4",
    dailyIncome: "১,৬৫০.০০",
    cost: "৬,৬০০.০০",
  },
  {
    vip: "VIP5",
    name: "BP Energy 5",
    dailyIncome: "৩,৫০০.০০",
    cost: "১২,৬০০.০০",
  },
  {
    vip: "VIP6",
    name: "BP Energy 6",
    dailyIncome: "৭,৪৪০.০০",
    cost: "২৫,০০০.০০",
  },
];

export default function BPInvestmentUI() {
  return (
    <div className="space-y-4">
      {investments.map((item, idx) => (
        <div key={idx} className="bg-white rounded-xl shadow p-4">
          <div className="flex justify-between items-center">
            <div>
              <span className="text-sm bg-purple-200 text-purple-800 px-2 py-1 rounded">{item.vip}</span>
              <h2 className="text-xl font-semibold text-green-700 mt-2">{item.name}</h2>
              <p className="text-sm text-gray-600">সময়কাল: ৯০ দিন</p>
              <p className="text-sm text-gray-800 mt-1">দিনের আয়: ৳{item.dailyIncome}</p>
              <p className="text-sm text-gray-800">প্রজন্ম মূল্য: ৳{item.cost}</p>
            </div>
            <div>
              <img src="/fuel.jpg" alt="Fuel Station" className="w-20 h-20 rounded-lg" />
            </div>
          </div>
          <button className="w-full mt-4 bg-green-500 text-white py-2 rounded">এখনই বিনিয়োগ করুন</button>
        </div>
      ))}
    </div>
  );
}
